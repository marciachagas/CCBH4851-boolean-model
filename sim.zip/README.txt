This folder contains all the results related to the creation of the Boolean model, trajectory simulation, and identification of the attractor basins for each of the 16 RNA-seq samples of CCBH4851 strain. Below is a brief description of its contents, in the order of usage:

	- CCBH-2022-for-script.csv: RRG file in the format used for the scripts.

	- "Normalization results" folder: Contains the normalized data of CCBH4851 in all 16 bulk RNA-seq samples, and the "RNA-seq_details" file containing detailed information on how the bulk RNA-seq experiments were conducted.

	- "translate" folder: Since the normalized data was provided by partners using a different genome nomenclature version, we created the translate.py script. This script reads the 	genome's .gff3 file, the list of genes from the Boolean model, and the normalized data from each sample in the previous folder (further information, including command-line usage, 
	can be found commented in the script). It provides a main resulting table for each sample, translated with only the genes from the subnetwork with the same locus used to construct 	the RRG of CCBH-2022, along with their normalized data. These tables were moved to their respective folders ("C1" refers to sample #1 and contains the "C1-translate_table," and so 	on).

	- "Binarization results" folder: The results of the bin.R script were manually combined into the file GENES-BIN.xlsx, which contains the following table in the "Names" sheet: the 	16 columns represent each RNA-seq experiment, the samples; the rows represent the results of each gene in each of the samples (the individual script results are in bin.zip). The 	titles 	of the following sheets represent the respective RNA-seq sample, and their columns represent the binarized value of each of the 211 genes in that sample. To facilitate data 	input in the command line, these sheets were separated into different .txt files in the folder. 

	- GRN_to_ASSA.py: GRN_to_ASSA.py is a script for creating the Boolean model. It generates two results: the input_to_assa.pbn (the Boolean model) and the conserved_genes.csv (a 	table that reports the genes with output edges present in the model).
	It is important to note that the gene IHF (integration host factor), one of the 212 genes, represents a complex composed of the products of the himA and himD genes. Due to this, it 	is not present in the CCBH4851 annotation as it is a complex, lacks a locus tag, and has no expression level in the RNA-seq (no binarized data). This complex regulates 30 	interactions in CCBH-2022, being a regulator with output edges and thus present in the subnetwork, controlling gene transcription and influencing the bacteria's growth rate 	(Zulianello et al.). To include it in the trajectory simulation, we manually defined the rule IHF -> himA & himD in the input_to_assa.pbn file (defined below), where IHF will only 	have a value of 1 if both himA and himD have a value of 1 since they are the genes that compose it. In the NAMES table, row 98 was also manually added following this rule, as for 	the simulation, the binarized data is used as initial data for the trajectory, following the order listed in "input_to_assa.pbn."
	The conserved_genes.csv initially consists of 47 genes. However, due to the IHF having its rule manually altered, depending on himA and himD, it gained an input edge as well. 	Therefore, it was manually removed from the conserved_genes.csv table. 
	Further information is contained as comments.
	
	- input_to_assa.pbn: The actual Boolean model file. This file contains the Boolean rules of the subnetwork.

	- commands.txt: Contains command lines for the trajectory simulation.

	- The simulation results are separately stored in folders corresponding to each sample (C1 contains C1_output.txt, and so on).

	- find_basin.py: Script for the identification of attractor basins. Further information is contained as comments. Its results (bar plots and "reached_basin" file) for each sample 	are also contained in their respective folders.

Additionally, the following files are present in the folder:
	- biof-polb-basins: Tables with the gene relations in the attractor basins of biofilm and polymyxin B samples (#11, #12, #13, #14), used in the article.
	- all-basins: Tables with the gene relations in the attractor basins of all samples.


REFERENCE:

Zulianello, L., de la Gorgue de Rosny, E., van Ulsen, P., van de Putte, P., & Goosen, N. (1994). The HimA and HimD subunits of integration host factor can specifically bind to DNA as homodimers. The EMBO Journal, 13(7), 1534–1540. https://doi.org/10.1002/j.1460-2075.1994.tb06415.x